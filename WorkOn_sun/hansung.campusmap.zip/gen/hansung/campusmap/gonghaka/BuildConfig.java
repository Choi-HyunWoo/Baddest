/** Automatically generated file. DO NOT MODIFY */
package hansung.campusmap.gonghaka;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}